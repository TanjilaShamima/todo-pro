import TodosFeature from "@/features/todos/TodosFeature";

export default function TodosPage() {
  return <TodosFeature />;
}
