import LoginFeature from "@/features/auth/LoginFeature";

export default function LoginPage() {
  return <LoginFeature />;
}
