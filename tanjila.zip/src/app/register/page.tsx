import RegisterFeature from "@/features/auth/RegisterFeature";

export default function RegisterPage() {
  return <RegisterFeature />;
}
